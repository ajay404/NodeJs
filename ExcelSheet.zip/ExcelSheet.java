import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelSheet {

	private  String titleOfSheet;



	public File createSheet(List<Object> listObj, HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		File file = new File(listObj.get(0).getClass().getSimpleName() + "ExportExcel.xlsx");

		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = workbook.createSheet(listObj.get(0).getClass().getSimpleName());
		setHeaders(listObj, workbook, sheet);
		setCellValues(listObj, workbook, sheet);
		setHeaderContent(listObj, workbook, sheet);
		setFilterData(listObj, workbook, sheet);

		try {
			FileOutputStream outputStream = new FileOutputStream(file);

			workbook.write(outputStream);
			workbook.close();
			downloadFIle(request, response, file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return file;

	}

	private void setHeaders(List<Object> listObj, XSSFWorkbook workbook, XSSFSheet sheet) {

		Field[] field = listObj.get(0).getClass().getDeclaredFields();
		int countColumn = 0;
		Row row = sheet.createRow(3);
		Cell cell = row.createCell(countColumn);
		row.setHeightInPoints(45.0f);

		for (Field fieldName : field) {
			cell = row.createCell(countColumn++);
			cell.setCellValue(
					(String) (fieldName.getName().substring(0, 1).toUpperCase() + fieldName.getName().substring(1)));

			cell.setCellStyle(setWorkbookStylesForHeader(workbook));

		}

	}

	private void setCellValues(List<Object> listObj, XSSFWorkbook workbook, XSSFSheet sheet) throws Exception {

		int rowCount = 4;
		int columnCount = 0;
		Row row = sheet.createRow(rowCount);
		Cell cell = row.createCell(columnCount);

		for (Object obj : listObj) {

			Field[] field = obj.getClass().getDeclaredFields();
			Method[] methods = obj.getClass().getMethods();

			for (Field fieldName : field) {

				for (Method methodsName : methods) {

					if (methodsName.getName().equalsIgnoreCase("get" + fieldName.getName())) {

						cell.setCellValue(String.valueOf(methodsName.invoke(obj)));

						cell.setCellStyle(setWorkbookStylesForCells(workbook, false));
						cell.getStringCellValue().split(" ");
						row.setHeightInPoints(45.0f);

						if (String.valueOf(methodsName.invoke(obj)).length() < fieldName.getName().length()) {
							sheet.setColumnWidth(columnCount, fieldName.getName().length() * 256 + 1280);
						} else {
							sheet.setColumnWidth(columnCount,
									String.valueOf(methodsName.invoke(obj)).length() * 256 + 2048);
						}


						if (row.getRowNum() == listObj.size() + 3) {
							cell.setCellStyle(setWorkbookStylesForCells(workbook, true));
						}

						cell = row.createCell(++columnCount);

					}
				}
			}
			row = sheet.createRow(++rowCount);

			columnCount = 0;
			cell = row.createCell(columnCount);
		}

	}

	private CellStyle setWorkbookStylesForCells(XSSFWorkbook workbook, boolean isLast) {

		XSSFCellStyle style = workbook.createCellStyle();
		if (isLast) {
			style.setBorderBottom(BorderStyle.MEDIUM);
		}
		style.setBorderRight(BorderStyle.MEDIUM);
		style.setAlignment(HorizontalAlignment.CENTER);
		style.setVerticalAlignment(VerticalAlignment.CENTER);
		style.setWrapText(true);

		return style;
	}

	private XSSFCellStyle setWorkbookStylesForHeader(XSSFWorkbook workbook) {

		XSSFCellStyle style = workbook.createCellStyle();

		style.setBorderTop(BorderStyle.MEDIUM);
		style.setBorderBottom(BorderStyle.MEDIUM);
		style.setBorderRight(BorderStyle.MEDIUM);
		style.setAlignment(HorizontalAlignment.CENTER);
		style.setVerticalAlignment(VerticalAlignment.CENTER);
		// style.setWrapText(true);

		return style;

	}

	private void setHeaderContent(List<Object> listObj, XSSFWorkbook workbook, XSSFSheet sheet) {

		Row row = sheet.createRow(0);
		Cell cell = row.createCell(0);
		setFontForHeader(workbook, cell);
		cell.setCellValue(titleOfSheet);

		// Merges the cells
		CellRangeAddress cellRangeAddress = new CellRangeAddress(0, 0, 0, 7);
		sheet.addMergedRegion(cellRangeAddress);

	}

	private void setFontForHeader(XSSFWorkbook workbook, Cell cell) {

		XSSFFont font = workbook.createFont();
		font.setBold(true);

		XSSFCellStyle style = workbook.createCellStyle();
		style.setFont(font);

		style.setAlignment(HorizontalAlignment.CENTER);
		cell.setCellStyle(style);

	}

	private void setFilterData(List<Object> listObj, XSSFWorkbook workbook, XSSFSheet sheet) {

		Row row = sheet.createRow(1);
		Cell cell = row.createCell(0);

		cell.setCellValue("Filter: ");

	}


	private void downloadFIle(HttpServletRequest request, HttpServletResponse response, File exportFile) {
		ServletContext ctx = request.getServletContext();
		InputStream fis = null;
		try {
			fis = new FileInputStream(exportFile);
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		String mimeType = ctx.getMimeType(exportFile.getAbsolutePath());
		response.setContentType(mimeType != null ? mimeType : "application/octet-stream");
		response.setContentLength((int) exportFile.length());
		response.setHeader("Content-Disposition", "attachment; filename=\"" + exportFile.getName() + "\"");

		ServletOutputStream os = null;
		try {
			os = response.getOutputStream();
		} catch (IOException ex) {
			ex.getMessage();
		}
		byte[] bufferData = new byte[1024];
		int read = 0;
		try {
			while ((read = fis.read(bufferData)) != -1) {
				os.write(bufferData, 0, read);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			os.flush();
			os.close();
			fis.close();
			if (exportFile.exists()) {
				exportFile.delete();
			}
			System.out.println("File Downloaded Successfully......");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
